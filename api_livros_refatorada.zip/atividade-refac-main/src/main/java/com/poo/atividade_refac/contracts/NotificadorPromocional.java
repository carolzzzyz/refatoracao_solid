package com.poo.atividade_refac.contracts;
public interface NotificadorPromocional { void notificar(); }
