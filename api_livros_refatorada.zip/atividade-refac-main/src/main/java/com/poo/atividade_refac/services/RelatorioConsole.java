package com.poo.atividade_refac.services;
import com.poo.atividade_refac.contracts.RelatorioLivros;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
@Component
public class RelatorioConsole implements RelatorioLivros {
    private static final Logger log = LoggerFactory.getLogger(RelatorioConsole.class);
    @Override public void registrarQuantidade(long quantidade) {
        log.info("Quantidade de livros: {}", quantidade);
    }
}
