package com.poo.atividade_refac.services;

/** Estratégia reutilizável para uma categoria com desconto fixo. */
public record DescontoPercentual(String categoria, double percentual) implements DescontoLivro {
    @Override
    public double aplicar(double preco) { return preco * (1 - percentual); }
}
