package com.poo.atividade_refac.services;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
@Configuration
public class DescontoConfig {
    @Bean public DescontoLivro descontoRomance() { return new DescontoPercentual("ROMANCE", 0.10); }
    @Bean public DescontoLivro descontoTecnologia() { return new DescontoPercentual("TECNOLOGIA", 0.20); }
    @Bean public DescontoLivro descontoInfantil() { return new DescontoPercentual("INFANTIL", 0.30); }
    @Bean public DescontoLivro descontoHq() { return new DescontoPercentual("HQ", 0.40); }
}
