package com.poo.atividade_refac.services;

import com.poo.atividade_refac.contracts.LivroService;
import com.poo.atividade_refac.contracts.NotificadorPromocional;
import com.poo.atividade_refac.contracts.RelatorioLivros;
import com.poo.atividade_refac.entities.Livro;
import com.poo.atividade_refac.repositories.LivroRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class LivroServiceImpl implements LivroService {
    private final LivroRepository repositorio;
    private final CalculadoraDesconto calculadora;
    private final RelatorioLivros relatorio;
    private final NotificadorPromocional notificador;

    public LivroServiceImpl(LivroRepository repositorio, CalculadoraDesconto calculadora,
                            RelatorioLivros relatorio, NotificadorPromocional notificador) {
        this.repositorio = repositorio;
        this.calculadora = calculadora;
        this.relatorio = relatorio;
        this.notificador = notificador;
    }

    @Override @Transactional(readOnly = true)
    public List<Livro> listar() { return repositorio.findAll(); }

    @Override @Transactional
    public Livro cadastrar(Livro livro) {
        validar(livro);
        livro.setId(null); // O servidor controla o ID no cadastro.
        livro.setPreco(calculadora.calcular(livro.getCategoria(), livro.getPreco()));
        Livro salvo = repositorio.save(livro);
        relatorio.registrarQuantidade(repositorio.count());
        notificador.notificar();
        return salvo;
    }

    @Override @Transactional
    public Livro atualizar(Long id, Livro livro) {
        validar(livro);
        Livro existente = buscar(id);
        existente.setTitulo(livro.getTitulo());
        existente.setAutor(livro.getAutor());
        existente.setPreco(livro.getPreco());
        existente.setCategoria(livro.getCategoria());
        // O original não aplicava desconto na atualização; este comportamento foi mantido.
        return repositorio.save(existente);
    }

    @Override @Transactional
    public void remover(Long id) {
        Livro livro = buscar(id);
        if ("RARO".equals(livro.getCategoria()))
            throw new IllegalArgumentException("Livros raros não podem ser removidos");
        repositorio.delete(livro);
    }

    private Livro buscar(Long id) {
        return repositorio.findById(id)
                .orElseThrow(() -> new LivroNaoEncontradoException(id));
    }

    private void validar(Livro livro) {
        if (livro == null || livro.getTitulo() == null || livro.getTitulo().isBlank())
            throw new IllegalArgumentException("Título obrigatório");
        if (livro.getPreco() == null || !Double.isFinite(livro.getPreco()) || livro.getPreco() <= 0)
            throw new IllegalArgumentException("Preço inválido");
    }
}
