package com.poo.atividade_refac.services;

import org.springframework.stereotype.Component;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class CalculadoraDesconto {
    private final Map<String, DescontoLivro> estrategias;

    public CalculadoraDesconto(List<DescontoLivro> descontosLivros) {
        this.estrategias = descontosLivros.stream()
                .collect(Collectors.toUnmodifiableMap(DescontoLivro::categoria, d -> d));
    }

    public double calcular(String categoria, double preco) {
        DescontoLivro desconto = estrategias.get(categoria);
        return desconto == null ? preco : desconto.aplicar(preco);
    }
}
