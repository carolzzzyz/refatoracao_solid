package com.poo.atividade_refac.services;
import com.poo.atividade_refac.contracts.NotificadorPromocional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
/** Mantém o comportamento original de simular o envio, sem afirmar que houve envio real. */
@Component
public class NotificadorConsole implements NotificadorPromocional {
    private static final Logger log = LoggerFactory.getLogger(NotificadorConsole.class);
    @Override public void notificar() { log.info("Email promocional enviado (simulado)"); }
}
