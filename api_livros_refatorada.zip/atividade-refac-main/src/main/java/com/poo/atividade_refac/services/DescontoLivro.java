package com.poo.atividade_refac.services;

/** Interface pequena para regras de precificação por categoria. */
public interface DescontoLivro {
    String categoria();
    double aplicar(double preco);
}
