package com.poo.atividade_refac;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.poo.atividade_refac.entities.Livro;
import com.poo.atividade_refac.repositories.LivroRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class LivroApiTests {
    @Autowired MockMvc mvc;
    @Autowired LivroRepository repository;

    @Test void cadastrarListarAtualizarRemover() throws Exception {
        var cadastro = mvc.perform(post("/livros").contentType(MediaType.APPLICATION_JSON)
            .content("{\"titulo\":\"Clean Code\",\"autor\":\"Robert C. Martin\",\"preco\":120,\"categoria\":\"TECNOLOGIA\"}"))
            .andExpect(status().isCreated()).andExpect(jsonPath("$.preco", is(96.0)))
            .andReturn();
        Long id = new ObjectMapper().readTree(cadastro.getResponse().getContentAsString()).get("id").asLong();
        mvc.perform(get("/livros")).andExpect(status().isOk());
        mvc.perform(put("/livros/" + id).contentType(MediaType.APPLICATION_JSON)
            .content("{\"titulo\":\"Clean Architecture\",\"autor\":\"Robert C. Martin\",\"preco\":150,\"categoria\":\"TECNOLOGIA\"}"))
            .andExpect(status().isOk()).andExpect(jsonPath("$.preco", is(150.0)));
        mvc.perform(delete("/livros/" + id)).andExpect(status().isNoContent());
        mvc.perform(delete("/livros/" + id)).andExpect(status().isNotFound());
    }

    @Test void validarEntradaERestricaoLivroRaro() throws Exception {
        mvc.perform(post("/livros").contentType(MediaType.APPLICATION_JSON)
            .content("{\"titulo\":\"\",\"preco\":12}"))
            .andExpect(status().isBadRequest());
        Livro raro = new Livro(null, "Exemplar", "Autor", 55.0, "RARO");
        Long id = repository.save(raro).getId();
        mvc.perform(delete("/livros/" + id)).andExpect(status().isBadRequest());
        repository.deleteById(id);
    }
}
